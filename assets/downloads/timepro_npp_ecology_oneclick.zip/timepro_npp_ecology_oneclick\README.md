# TimePro-LSTM：月尺度与年尺度一键NPP建模

项目提供两个可以直接双击的版本：

- 月尺度：`run_monthly.bat`
- 年尺度：`run_annual.bat`

第一次运行会自动创建Python环境、生成模拟站点CSV、按站点划分训练/验证数据、
自动寻找时间窗口和模型参数，然后保存模型与诊断结果。

## 模型到底预测什么

对目标时刻 `t`：

```text
X输入：从 t-x_window+1 到 t 的A、B、C、D……（包含目标期已知X_t）
Y输入：从 t-y_lags 到 t-1 的历史Y（绝不包含真实Y_t）
标签：Y_t
```

公式为：

```text
Y_t = f(X[t-x_window+1:t], Y[t-y_lags:t-1])
```

`x_window`和`y_lags`分别自动选择。`y_lags=0`代表完全不用历史Y。

## 月尺度版

修改`config_monthly.yaml`：

```yaml
data:
  station_csv: D:/你的目录/月尺度站点数据.csv
  site_column: site_id
  time_column: date
  target_column: Y
  feature_columns: []
  create_demo_if_missing: false
```

然后双击`run_monthly.bat`。默认搜索：

```text
X窗口：1、3、6、12、24个月
历史Y：0、1、3、6、12个月
```

结果保存到`outputs_monthly`。

## 年尺度版

修改`config_annual.yaml`，然后双击`run_annual.bat`。默认搜索：

```text
X窗口：1、2、3、5年
历史Y：0、1、2、3年
```

结果保存到`outputs_annual`。

## CSV格式

月版和年版使用相同的长表结构，区别仅在date的间隔：

```text
site_id,date,A,B,C,D,Y
S001,2015-01-01,10.2,51.0,130.1,0.42,503.2
S001,2015-02-01,11.8,63.2,141.5,0.46,528.7
S002,2015-01-01,8.1,47.5,125.4,0.39,471.6
```

`feature_columns: []`时，程序把site/date/Y之外的数值列自动识别为X。如果CSV还
包含不想使用的数值列，应明确写成：

```yaml
feature_columns: [A, B, C, D]
```

## 自动比较M0、M1、M2

参数搜索首先强制比较三种模型：

- M0：当期X，`x_window=1, y_lags=0`
- M1：一段时间X，`x_window>1, y_lags=0`
- M2：一段时间X和历史Y，`x_window>1, y_lags>0`

后续试验随机探索其他窗口和网络参数。`parameter_trials.csv`记录每种组合，因此
可以判断提升究竟来自时间窗口还是历史Y。

## 数据划分与成功阈值

- 70%站点进入训练池。
- 调参只在这70%站点内部进行。
- 选定参数后，用全部70%站点重新训练。
- 其余30%站点完全不参与训练和调参，只做最终独立验证。
- `r2_threshold: 0.70`可修改。

不能随机拆分CSV行，否则同一站点的相邻时间可能同时出现在训练和验证中，造成
虚高R2。

## 输出文件

月版或年版的输出目录中包括：

- `best_model.pt`：模型、变量顺序、窗口、标准化参数。
- `metrics.json`：总体R2、RMSE、MAE、逐站点R2中位数。
- `parameter_trials.csv`：M0/M1/M2及其他自动调参试验。
- `held_out_predictions.csv`：独立站点实测值和预测值。
- `per_station_metrics.csv`：逐站点指标。
- `station_split.csv`：训练站点和独立验证站点名单。
- `validation_scatter.png`、`validation_residuals.png`：诊断图。

即使R2没有达到阈值，模型和诊断结果仍会保存，不会伪造成功。

## 栅格递推

月版目录示例：

```text
raster_data/monthly/
├─ history/
│  ├─ A/  2024-01.tif, 2024-02.tif, ...
│  ├─ B/  2024-01.tif, 2024-02.tif, ...
│  ├─ C/  2024-01.tif, 2024-02.tif, ...
│  ├─ D/  2024-01.tif, 2024-02.tif, ...
│  └─ Y/  2024-01.tif, 2024-02.tif, ...
└─ future/
   ├─ A/  2026-01.tif, 2026-02.tif, ...
   ├─ B/  2026-01.tif, 2026-02.tif, ...
   ├─ C/  2026-01.tif, 2026-02.tif, ...
   └─ D/  2026-01.tif, 2026-02.tif, ...
```

年版使用`raster_data/annual`，文件名换成年份即可。同一期各变量必须使用相同
文件名。

- 月版栅格：修改`raster_config_monthly.yaml`，双击`run_raster_monthly.bat`
- 年版栅格：修改`raster_config_annual.yaml`，双击`run_raster_annual.bat`

栅格代码读取最优模型中的`x_window`和`y_lags`。预测下一期后，把当期X和预测Y
分别压入历史缓冲区继续递推。代码默认所有栅格已经对齐，不负责重投影和重采样。

## 月还是年

月尺度能保留生长季和月际滞后，但噪声、季节自相关也更强；年尺度更稳定，但样本
更少且会丢失季节信息。若最终目标是年度NPP，另一种很有价值的设计是“12或24个
月的气候序列预测当年总NPP”，该混合频率模式尚未在本版自动展开。

模拟数据只用于证明代码流程能跑通。真实NPP能否超过0.7取决于数据质量、站点数、
变量、时间长度和空间外推难度。

