# 来源与范围说明

论文：

> Ma, X., Ni, Z.-L., Xiao, S. & Chen, X. TimePro: Efficient Multivariate
> Long-term Time Series Forecasting with Variable- and Time-Aware Hyper-state.
> ICML 2025, PMLR 267:42096–42111.

- 论文：https://proceedings.mlr.press/v267/ma25p.html
- 官方代码：https://github.com/xwmaxwma/TimePro

本代码包没有复制官方CUDA selective scan或DCNv4实现。它保留“分变量时间片、
变量交互和变量特异时间窗口”的建模思路，并使用纯PyTorch Transformer、X-LSTM、
Y-LSTM和门控融合重新实现单目标X→Y任务，以降低Windows安装门槛。

正式研究引用TimePro思想时，应引用原论文；描述本代码时应写
“TimePro-inspired ecological adaptation”，不要声称复现了原版HyperMamba。

