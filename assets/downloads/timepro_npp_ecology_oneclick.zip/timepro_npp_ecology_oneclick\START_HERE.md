# 先看这里

## 选择一个入口

月尺度数据：

1. 修改 `config_monthly.yaml` 中的CSV路径和列名；
2. 双击 `run_monthly.bat`；
3. 在 `outputs_monthly` 查看结果。

年尺度数据：

1. 修改 `config_annual.yaml`；
2. 双击 `run_annual.bat`；
3. 在 `outputs_annual` 查看结果。

第一次运行会创建`.venv`并安装依赖。CSV不存在且
`create_demo_if_missing: true`时，程序自动生成模拟数据。

## 模型输入

```text
X[t-x_window+1:t] + Y[t-y_lags:t-1] -> Y_t
```

目标期已知X可以输入，目标期真实Y不能输入。`x_window`和`y_lags`分别调参。

## 重要边界

- 这是TimePro-inspired生态改造版，不是官方HyperMamba/DCNv4逐行复刻。
- 当前训练器面向规则连续时间序列。真实站点中间缺月或缺年时，不要直接把断裂
  两侧当作连续窗口。
- 不同站点不能首尾拼成一条时间序列。
- 稀疏Y更适合采用“连续气候X窗口＋静态空间属性→观测Y”的面板建模方式。
- 模拟数据结果只用于检查程序，不代表真实NPP精度。

完整说明见`README.md`。

