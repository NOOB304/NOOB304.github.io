from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def generate_demo_station_data(
    output_path: str | Path,
    num_sites: int = 48,
    num_timesteps: int = 84,
    seed: int = 2026,
    frequency: str = "monthly",
) -> Path:
    """
    Generate monthly or annual station data with known lag relationships.

    A: temperature-like variable
    B: precipitation-like variable
    C: radiation-like variable
    D: soil-moisture-like variable
    Y: NPP-like target with autocorrelation and delayed climate effects
    """
    rng = np.random.default_rng(seed)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    frequency = frequency.lower()
    if frequency == "monthly":
        dates = pd.date_range("2015-01-01", periods=num_timesteps, freq="MS")
    elif frequency == "annual":
        dates = pd.date_range("1990-01-01", periods=num_timesteps, freq="YS")
    else:
        raise ValueError("frequency must be 'monthly' or 'annual'")

    for site_index in range(num_sites):
        phase = rng.uniform(-0.5, 0.5)
        site_temp = rng.normal(0.0, 2.5)
        site_wetness = rng.normal(0.0, 8.0 if frequency == "monthly" else 90.0)
        site_productivity = rng.normal(0.0, 18.0)

        a = np.zeros(num_timesteps)
        b = np.zeros(num_timesteps)
        c = np.zeros(num_timesteps)
        d = np.zeros(num_timesteps)
        y = np.zeros(num_timesteps)

        for t in range(num_timesteps):
            if frequency == "monthly":
                seasonal = np.sin(2 * np.pi * (t / 12 + phase))
                seasonal_shifted = np.sin(
                    2 * np.pi * (t / 12 + phase - 0.18)
                )
                a[t] = (
                    13.0
                    + site_temp
                    + 10.0 * seasonal
                    + rng.normal(0, 1.1)
                )
                b[t] = max(
                    2.0,
                    65.0
                    + site_wetness
                    + 28.0 * seasonal_shifted
                    + rng.normal(0, 8.0),
                )
                c[t] = 155.0 + 48.0 * seasonal + rng.normal(0, 6.0)
                previous_d = (
                    d[t - 1] if t > 0 else 0.48 + rng.normal(0, 0.03)
                )
                d[t] = np.clip(
                    0.70 * previous_d
                    + 0.0030 * b[t]
                    - 0.0060 * max(a[t], 0)
                    + rng.normal(0, 0.025),
                    0.05,
                    0.95,
                )
                b_lag = b[max(0, t - 2)]
                d_lag = d[max(0, t - 1)]
                temperature_response = (
                    16.0 * a[t] - 0.38 * (a[t] - 18.0) ** 2
                )
                climate_capacity = (
                    210.0
                    + temperature_response
                    + 0.95 * b_lag
                    + 0.62 * c[t]
                    + 145.0 * d_lag
                    + site_productivity
                )
                noise_sd = 10.0
                persistence = 0.50
                lag2_weight = 0.08
            else:
                multi_year_cycle = np.sin(2 * np.pi * (t / 7.0 + phase))
                a[t] = (
                    10.5
                    + site_temp
                    + 0.035 * t
                    + 1.8 * multi_year_cycle
                    + rng.normal(0, 0.7)
                )
                b[t] = max(
                    120.0,
                    720.0
                    + site_wetness
                    + 105.0 * np.sin(
                        2 * np.pi * (t / 5.0 + phase - 0.15)
                    )
                    + rng.normal(0, 45.0),
                )
                c[t] = (
                    1820.0
                    + 75.0 * multi_year_cycle
                    + rng.normal(0, 35.0)
                )
                previous_d = (
                    d[t - 1] if t > 0 else 0.52 + rng.normal(0, 0.03)
                )
                d[t] = np.clip(
                    0.62 * previous_d
                    + 0.00028 * b[t]
                    - 0.008 * max(a[t] - 10.0, 0)
                    + rng.normal(0, 0.025),
                    0.08,
                    0.95,
                )
                b_lag = b[max(0, t - 1)]
                d_lag = d[max(0, t - 1)]
                temperature_response = (
                    19.0 * a[t] - 0.48 * (a[t] - 16.0) ** 2
                )
                climate_capacity = (
                    160.0
                    + temperature_response
                    + 0.22 * b_lag
                    + 0.16 * c[t]
                    + 190.0 * d_lag
                    + site_productivity
                )
                noise_sd = 13.0
                persistence = 0.56
                lag2_weight = 0.07

            if t == 0:
                y[t] = climate_capacity + rng.normal(0, noise_sd)
            else:
                y_lag2 = y[max(0, t - 2)]
                y[t] = (
                    persistence * y[t - 1]
                    + lag2_weight * y_lag2
                    + (1.0 - persistence - lag2_weight) * climate_capacity
                    + rng.normal(0, noise_sd)
                )

            rows.append(
                {
                    "site_id": f"S{site_index + 1:03d}",
                    "date": dates[t].strftime("%Y-%m-%d"),
                    "A": round(float(a[t]), 5),
                    "B": round(float(b[t]), 5),
                    "C": round(float(c[t]), 5),
                    "D": round(float(d[t]), 6),
                    "Y": round(float(y[t]), 5),
                }
            )

    pd.DataFrame(rows).to_csv(output_path, index=False, encoding="utf-8-sig")
    return output_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="data/demo_station_data.csv")
    parser.add_argument("--sites", type=int, default=48)
    parser.add_argument("--timesteps", type=int, default=84)
    parser.add_argument(
        "--frequency", choices=["monthly", "annual"], default="monthly"
    )
    args = parser.parse_args()
    path = generate_demo_station_data(
        args.output,
        args.sites,
        args.timesteps,
        frequency=args.frequency,
    )
    print(f"演示数据已生成: {path}")
