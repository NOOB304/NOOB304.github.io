from __future__ import annotations

import argparse
from contextlib import ExitStack
from pathlib import Path

import numpy as np
import torch
import yaml

from src.model import build_model
from src.training import choose_device

try:
    import rasterio
except ImportError as exc:
    raise SystemExit(
        "缺少 rasterio。请运行对应的 run_raster_*.bat 自动安装。"
    ) from exc


PROJECT_DIR = Path(__file__).resolve().parent


def project_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else PROJECT_DIR / path


def load_checkpoint(path: Path, device: torch.device) -> dict:
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=device)


def read_window_as_nan(source, window) -> np.ndarray:
    return (
        source.read(1, window=window, masked=True)
        .filled(np.nan)
        .astype(np.float32)
    )


def batched_predict(
    model,
    x_sequence_raw: np.ndarray,
    y_history_raw: np.ndarray,
    mean: np.ndarray,
    std: np.ndarray,
    device: torch.device,
    batch_pixels: int,
) -> np.ndarray:
    x_normalized = (
        x_sequence_raw - mean[None, None, :-1]
    ) / std[None, None, :-1]
    y_normalized = (
        y_history_raw - mean[-1]
    ) / std[-1]
    outputs: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(x_sequence_raw), batch_pixels):
            end = min(start + batch_pixels, len(x_sequence_raw))
            x_tensor = torch.from_numpy(
                x_normalized[start:end].astype(np.float32)
            ).to(device)
            y_tensor = torch.from_numpy(
                y_normalized[start:end].astype(np.float32)
            ).to(device)
            prediction_normalized = model(x_tensor, y_tensor).cpu().numpy()
            outputs.append(prediction_normalized)
    prediction_normalized = np.concatenate(outputs)
    return prediction_normalized * std[-1] + mean[-1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        default="raster_config_monthly.yaml",
        help="月版或年版栅格配置文件",
    )
    args = parser.parse_args()
    with project_path(args.config).open("r", encoding="utf-8") as file:
        config = yaml.safe_load(file)

    device = choose_device(config.get("device", "auto"))
    checkpoint_path = project_path(config["model_checkpoint"])
    checkpoint = load_checkpoint(checkpoint_path, device)
    feature_columns = checkpoint["feature_columns"]
    target_column = checkpoint["target_column"]
    params = checkpoint["model_params"]
    x_window = int(params["x_window"])
    y_lags = int(params["y_lags"])
    x_history_count = x_window - 1
    scaler = checkpoint["scaler"]
    mean = np.asarray(scaler["mean"], dtype=np.float32)
    std = np.asarray(scaler["std"], dtype=np.float32)

    model = build_model(len(feature_columns), params)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.to(device)

    history_dir = project_path(config["history_dir"])
    future_dir = project_path(config["future_dir"])
    output_dir = project_path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    pattern = config.get("file_pattern", "*.tif")
    nodata = float(config.get("output_nodata", -9999.0))
    batch_pixels = int(config.get("inference_batch_pixels", 8192))

    if x_history_count > 0:
        x_history_names = sorted(
            path.name
            for path in (history_dir / feature_columns[0]).glob(pattern)
        )[-x_history_count:]
        if len(x_history_names) < x_history_count:
            raise ValueError(
                f"历史X只有{len(x_history_names)}期，模型需要{x_history_count}期。"
            )
    else:
        x_history_names = []

    if y_lags > 0:
        y_history_names = sorted(
            path.name for path in (history_dir / target_column).glob(pattern)
        )[-y_lags:]
        if len(y_history_names) < y_lags:
            raise ValueError(
                f"历史Y只有{len(y_history_names)}期，模型需要{y_lags}期。"
            )
    else:
        y_history_names = []

    future_names = sorted(
        path.name for path in (future_dir / feature_columns[0]).glob(pattern)
    )
    if not future_names:
        raise ValueError("future目录中没有找到未来X栅格。")

    print(
        f"模型：X窗口={x_window}期，历史Y={y_lags}期；"
        f"将递推预测未来{len(future_names)}期。"
    )
    print(f"X变量顺序：{feature_columns}；目标：{target_column}")

    with ExitStack() as stack:
        x_history_sources = {
            variable: [
                stack.enter_context(
                    rasterio.open(history_dir / variable / filename)
                )
                for filename in x_history_names
            ]
            for variable in feature_columns
        }
        y_history_sources = [
            stack.enter_context(
                rasterio.open(history_dir / target_column / filename)
            )
            for filename in y_history_names
        ]
        future_sources = {
            variable: [
                stack.enter_context(
                    rasterio.open(future_dir / variable / filename)
                )
                for filename in future_names
            ]
            for variable in feature_columns
        }
        template = future_sources[feature_columns[0]][0]
        profile = template.profile.copy()
        profile.update(
            dtype="float32",
            count=1,
            nodata=nodata,
            compress="deflate",
        )
        output_sources = [
            stack.enter_context(
                rasterio.open(output_dir / filename, "w", **profile)
            )
            for filename in future_names
        ]

        for block_number, (_, window) in enumerate(
            template.block_windows(1), start=1
        ):
            pixel_count = int(window.height) * int(window.width)
            x_steps: list[np.ndarray] = []
            for time_index in range(x_history_count):
                arrays = [
                    read_window_as_nan(
                        x_history_sources[variable][time_index], window
                    ).reshape(-1)
                    for variable in feature_columns
                ]
                x_steps.append(np.column_stack(arrays))
            if x_steps:
                x_history_raw = np.stack(x_steps, axis=1)
            else:
                x_history_raw = np.empty(
                    (pixel_count, 0, len(feature_columns)), dtype=np.float32
                )

            if y_lags > 0:
                y_history_raw = np.stack(
                    [
                        read_window_as_nan(source, window).reshape(-1)
                        for source in y_history_sources
                    ],
                    axis=1,
                )[:, :, None]
            else:
                # Placeholder ignored by models trained with y_lags=0.
                y_history_raw = np.zeros(
                    (pixel_count, 1, 1), dtype=np.float32
                )

            active = np.isfinite(x_history_raw).all(axis=(1, 2))
            if y_lags > 0:
                active &= np.isfinite(y_history_raw).all(axis=(1, 2))

            for time_index, output_source in enumerate(output_sources):
                current_arrays = [
                    read_window_as_nan(
                        future_sources[variable][time_index], window
                    ).reshape(-1)
                    for variable in feature_columns
                ]
                current_x_raw = np.column_stack(current_arrays)
                active &= np.isfinite(current_x_raw).all(axis=1)
                x_sequence_raw = np.concatenate(
                    [x_history_raw, current_x_raw[:, None, :]], axis=1
                )

                output_flat = np.full(
                    pixel_count, nodata, dtype=np.float32
                )
                if active.any():
                    predicted_y = batched_predict(
                        model,
                        x_sequence_raw[active],
                        y_history_raw[active],
                        mean,
                        std,
                        device,
                        batch_pixels,
                    )
                    output_flat[active] = predicted_y.astype(np.float32)

                output_source.write(
                    output_flat.reshape(
                        int(window.height), int(window.width)
                    ),
                    1,
                    window=window,
                )

                if x_history_count > 0:
                    x_history_raw = x_sequence_raw[:, -x_history_count:, :]
                if y_lags > 0:
                    appended_y = output_flat.astype(np.float32)
                    appended_y[~active] = np.nan
                    y_history_raw = np.concatenate(
                        [y_history_raw, appended_y[:, None, None]], axis=1
                    )[:, -y_lags:, :]

            if block_number % 20 == 0:
                print(f"已处理{block_number}个栅格块……")

    print(f"栅格预测完成：{output_dir}")


if __name__ == "__main__":
    main()

