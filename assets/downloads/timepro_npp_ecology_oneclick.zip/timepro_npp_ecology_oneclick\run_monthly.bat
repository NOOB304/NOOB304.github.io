@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating Python environment...
    py -3 -m venv .venv 2>nul
    if errorlevel 1 python -m venv .venv

    echo [2/3] Installing training packages. The first run can take several minutes...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
)

echo [3/3] Starting MONTHLY model...
".venv\Scripts\python.exe" run_training.py --config config_monthly.yaml

echo.
echo Finished. See outputs_monthly.
pause

