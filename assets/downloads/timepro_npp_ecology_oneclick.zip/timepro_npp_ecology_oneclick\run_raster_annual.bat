@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Please run run_annual.bat first.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -m pip install -r requirements-raster.txt
".venv\Scripts\python.exe" predict_rasters.py --config raster_config_annual.yaml
pause

