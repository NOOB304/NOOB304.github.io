from __future__ import annotations

import json
import argparse
from pathlib import Path

import yaml

from generate_demo_data import generate_demo_station_data
from src.data import load_station_csv
from src.training import train_pipeline


PROJECT_DIR = Path(__file__).resolve().parent


def project_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else PROJECT_DIR / path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        default="config_monthly.yaml",
        help="月版使用 config_monthly.yaml，年版使用 config_annual.yaml",
    )
    args = parser.parse_args()
    config_path = project_path(args.config)
    with config_path.open("r", encoding="utf-8") as file:
        config = yaml.safe_load(file)

    csv_path = project_path(config["data"]["station_csv"])
    if not csv_path.exists():
        if not config["data"].get("create_demo_if_missing", False):
            raise FileNotFoundError(f"找不到站点 CSV：{csv_path}")
        print(f"未找到 {csv_path.name}，正在自动生成演示站点数据……")
        generate_demo_station_data(
            csv_path,
            int(config["data"].get("demo_num_sites", 48)),
            int(config["data"].get("demo_num_timesteps", 84)),
            seed=int(config["split"]["seed"]) + 100,
            frequency=config["data"].get("demo_frequency", "monthly"),
        )
        print(f"演示数据已生成：{csv_path}")

    frame, feature_columns = load_station_csv(
        csv_path,
        config["data"]["site_column"],
        config["data"]["time_column"],
        config["data"]["target_column"],
        config["data"].get("feature_columns"),
    )
    output_dir = project_path(config["output_dir"])
    summary = train_pipeline(frame, feature_columns, config, output_dir)

    held_out = summary["held_out_metrics"]
    print("\n" + "=" * 62)
    print(
        f"最终独立站点验证：R2={held_out['r2']:.4f}，"
        f"RMSE={held_out['rmse']:.3f}，MAE={held_out['mae']:.3f}"
    )
    print(f"各站点 R2 中位数：{summary['median_station_r2']:.4f}")
    if summary["success"]:
        print(
            f"建模成功：R2 已达到阈值 {summary['r2_threshold']:.2f}。"
        )
    else:
        print(
            f"未达到阈值 {summary['r2_threshold']:.2f}。"
            "模型和诊断结果仍已保存，请检查数据与变量。"
        )
    print(f"结果目录：{output_dir}")
    print("=" * 62)
    print(json.dumps(summary["best_params"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
