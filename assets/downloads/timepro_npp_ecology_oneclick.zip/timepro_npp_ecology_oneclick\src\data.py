from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


@dataclass
class Standardization:
    columns: list[str]
    mean: np.ndarray
    std: np.ndarray

    @classmethod
    def fit(cls, frame: pd.DataFrame, columns: Sequence[str]) -> "Standardization":
        values = frame[list(columns)].to_numpy(dtype=np.float64)
        mean = np.nanmean(values, axis=0)
        std = np.nanstd(values, axis=0)
        std[std < 1e-8] = 1.0
        return cls(list(columns), mean.astype(np.float32), std.astype(np.float32))

    def transform(self, values: np.ndarray) -> np.ndarray:
        return (values - self.mean) / self.std

    def inverse_y(self, values: np.ndarray) -> np.ndarray:
        return values * self.std[-1] + self.mean[-1]

    def to_dict(self) -> dict:
        return {
            "columns": self.columns,
            "mean": self.mean.tolist(),
            "std": self.std.tolist(),
        }


def load_station_csv(
    csv_path: str | Path,
    site_column: str,
    time_column: str,
    target_column: str,
    configured_features: Sequence[str] | None,
) -> tuple[pd.DataFrame, list[str]]:
    frame = pd.read_csv(csv_path)
    required = {site_column, time_column, target_column}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"CSV 缺少必要列: {missing}")

    frame[time_column] = pd.to_datetime(frame[time_column])
    frame = frame.sort_values([site_column, time_column]).reset_index(drop=True)

    if configured_features:
        feature_columns = list(configured_features)
    else:
        excluded = {site_column, time_column, target_column}
        feature_columns = [
            column
            for column in frame.columns
            if column not in excluded
            and pd.api.types.is_numeric_dtype(frame[column])
        ]
    if not feature_columns:
        raise ValueError("没有找到可用的 X 变量。请在 config.yaml 指定 feature_columns。")

    numeric_columns = feature_columns + [target_column]
    frame[numeric_columns] = frame[numeric_columns].apply(
        pd.to_numeric, errors="coerce"
    )
    before = len(frame)
    frame = frame.dropna(
        subset=[site_column, time_column, *numeric_columns]
    ).reset_index(drop=True)
    removed = before - len(frame)
    if removed:
        print(f"提示：删除了 {removed} 行含缺失值的数据。")

    duplicate = frame.duplicated([site_column, time_column]).sum()
    if duplicate:
        raise ValueError(
            f"发现 {duplicate} 个重复的 站点-时间 组合，请先处理后再训练。"
        )
    return frame, feature_columns


class StationSequenceDataset(Dataset):
    def __init__(
        self,
        frame: pd.DataFrame,
        site_ids: Sequence,
        site_column: str,
        time_column: str,
        feature_columns: Sequence[str],
        target_column: str,
        x_window: int,
        y_lags: int,
        scaler: Standardization,
    ) -> None:
        super().__init__()
        history_columns = list(feature_columns) + [target_column]
        x_sequences: list[np.ndarray] = []
        y_histories: list[np.ndarray] = []
        targets: list[float] = []
        metadata: list[tuple[str, str]] = []

        selected = frame[frame[site_column].isin(site_ids)]
        for site_id, group in selected.groupby(site_column, sort=False):
            group = group.sort_values(time_column)
            raw = group[history_columns].to_numpy(dtype=np.float32)
            normalized = scaler.transform(raw).astype(np.float32)
            times = group[time_column].dt.strftime("%Y-%m-%d").tolist()

            first_target = max(x_window - 1, y_lags)
            for target_index in range(first_target, len(group)):
                x_sequences.append(
                    normalized[
                        target_index - x_window + 1 : target_index + 1,
                        :-1,
                    ]
                )
                if y_lags > 0:
                    y_histories.append(
                        normalized[
                            target_index - y_lags : target_index, -1:
                        ]
                    )
                else:
                    # Stable batch shape; the model ignores this placeholder.
                    y_histories.append(np.zeros((1, 1), dtype=np.float32))
                targets.append(float(normalized[target_index, -1]))
                metadata.append((str(site_id), times[target_index]))

        if not x_sequences:
            minimum_rows = max(x_window, y_lags + 1)
            raise ValueError(
                f"没有可用序列。每个站点至少需要 {minimum_rows} 条记录。"
            )
        self.x_sequences = torch.from_numpy(np.stack(x_sequences))
        self.y_histories = torch.from_numpy(np.stack(y_histories))
        self.targets = torch.tensor(targets, dtype=torch.float32)
        self.metadata = metadata

    def __len__(self) -> int:
        return len(self.targets)

    def __getitem__(self, index: int):
        return (
            self.x_sequences[index],
            self.y_histories[index],
            self.targets[index],
            index,
        )
