from __future__ import annotations

import math
from typing import Any

import torch
from torch import nn


class TimeProLSTMFusion(nn.Module):
    """
    A Windows-friendly TimePro-inspired forecasting model.

    Inputs
    ------
    x_sequence:
        [batch, x_window, num_x]. Its last row is the known X at target time t.
    y_history:
        [batch, y_lags, 1]. It contains only Y before t. If y_lags=0,
        the dataset supplies one zero placeholder that the model ignores.

    Architecture
    ------------
    1. Variable-wise overlapping X patches preserve variable-specific delays.
    2. A temporal Transformer learns long/short lag patterns within each variable.
    3. A variable Transformer and target query learn interactions among variables.
    4. Separate X-LSTM and Y-LSTM branches retain local dynamics without leaking Y_t.
    5. Known current X is fused with all historical branches.
    """

    def __init__(
        self,
        num_x: int,
        x_window: int,
        y_lags: int,
        patch_len: int,
        d_model: int,
        n_heads: int,
        temporal_layers: int,
        variable_layers: int,
        lstm_hidden: int,
        dropout: float,
    ) -> None:
        super().__init__()
        if patch_len > x_window:
            raise ValueError("patch_len cannot exceed x_window")
        if d_model % n_heads != 0:
            raise ValueError("d_model must be divisible by n_heads")

        self.num_x = num_x
        self.x_window = x_window
        self.y_lags = y_lags
        self.patch_len = patch_len
        self.patch_stride = max(1, patch_len // 2)
        self.num_patches = 1 + (x_window - patch_len) // self.patch_stride
        self.d_model = d_model

        self.patch_projection = nn.Linear(patch_len, d_model)
        self.patch_position = nn.Parameter(
            torch.zeros(1, 1, self.num_patches, d_model)
        )
        self.variable_embedding = nn.Parameter(
            torch.zeros(1, self.num_x, 1, d_model)
        )

        temporal_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 3,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.temporal_encoder = nn.TransformerEncoder(
            temporal_layer,
            num_layers=temporal_layers,
            enable_nested_tensor=False,
        )

        variable_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 3,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.variable_encoder = nn.TransformerEncoder(
            variable_layer,
            num_layers=variable_layers,
            enable_nested_tensor=False,
        )
        self.target_query = nn.Parameter(torch.zeros(1, 1, d_model))
        self.target_attention = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True
        )

        self.x_lstm = nn.LSTM(
            input_size=self.num_x,
            hidden_size=lstm_hidden,
            num_layers=1,
            batch_first=True,
        )
        self.x_lstm_projection = nn.Linear(lstm_hidden, d_model)

        y_hidden = max(8, lstm_hidden // 2)
        self.y_lstm = nn.LSTM(
            input_size=1,
            hidden_size=y_hidden,
            num_layers=1,
            batch_first=True,
        )
        self.y_lstm_projection = nn.Linear(y_hidden, d_model)
        self.no_y_context = nn.Parameter(torch.zeros(1, d_model))

        self.current_x_projection = nn.Sequential(
            nn.Linear(num_x, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, d_model),
        )

        self.fusion_weights = nn.Linear(d_model * 4, 4)
        self.output_head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, 1),
        )
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.trunc_normal_(self.patch_position, std=0.02)
        nn.init.trunc_normal_(self.variable_embedding, std=0.02)
        nn.init.trunc_normal_(self.target_query, std=0.02)
        nn.init.trunc_normal_(self.no_y_context, std=0.02)

    def forward(
        self, x_sequence: torch.Tensor, y_history: torch.Tensor
    ) -> torch.Tensor:
        batch_size = x_sequence.shape[0]

        # [B, Lx, N] -> [B, N, P, patch_len]
        patches = (
            x_sequence.transpose(1, 2)
            .unfold(dimension=-1, size=self.patch_len, step=self.patch_stride)
        )
        patch_tokens = self.patch_projection(patches)
        patch_tokens = (
            patch_tokens
            + self.patch_position
            + self.variable_embedding
        )

        # The same temporal encoder is applied independently to every variable.
        patch_tokens = patch_tokens.reshape(
            batch_size * self.num_x,
            self.num_patches,
            self.d_model,
        )
        patch_tokens = self.temporal_encoder(patch_tokens)
        variable_tokens = patch_tokens.mean(dim=1).reshape(
            batch_size, self.num_x, self.d_model
        )
        variable_tokens = self.variable_encoder(variable_tokens)

        query = self.target_query.expand(batch_size, -1, -1)
        timepro_context, _ = self.target_attention(
            query, variable_tokens, variable_tokens, need_weights=False
        )
        timepro_context = timepro_context[:, 0, :]

        _, (x_hidden, _) = self.x_lstm(x_sequence)
        local_x_context = self.x_lstm_projection(x_hidden[-1])
        if self.y_lags > 0:
            _, (y_hidden, _) = self.y_lstm(y_history)
            y_context = self.y_lstm_projection(y_hidden[-1])
        else:
            y_context = self.no_y_context.expand(batch_size, -1)
        current_context = self.current_x_projection(x_sequence[:, -1, :])

        all_context = torch.cat(
            [timepro_context, local_x_context, y_context, current_context],
            dim=-1,
        )
        weights = torch.softmax(self.fusion_weights(all_context), dim=-1)
        stacked = torch.stack(
            [timepro_context, local_x_context, y_context, current_context],
            dim=1,
        )
        fused = (stacked * weights.unsqueeze(-1)).sum(dim=1)

        return self.output_head(fused).squeeze(-1)


def build_model(num_x: int, params: dict[str, Any]) -> TimeProLSTMFusion:
    return TimeProLSTMFusion(
        num_x=num_x,
        x_window=int(params["x_window"]),
        y_lags=int(params["y_lags"]),
        patch_len=int(params["patch_len"]),
        d_model=int(params["d_model"]),
        n_heads=int(params["n_heads"]),
        temporal_layers=int(params["temporal_layers"]),
        variable_layers=int(params["variable_layers"]),
        lstm_hidden=int(params["lstm_hidden"]),
        dropout=float(params["dropout"]),
    )


def count_parameters(model: nn.Module) -> int:
    return sum(math.prod(parameter.shape) for parameter in model.parameters())
