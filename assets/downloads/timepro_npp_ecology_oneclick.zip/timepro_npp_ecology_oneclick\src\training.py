from __future__ import annotations

import copy
import json
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from torch import nn
from torch.utils.data import DataLoader

from .data import Standardization, StationSequenceDataset
from .model import build_model, count_parameters


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def choose_device(requested: str) -> torch.device:
    requested = requested.lower()
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        print("未检测到可用 CUDA，自动改用 CPU。")
        return torch.device("cpu")
    return torch.device(requested)


def split_station_ids(
    station_ids: Sequence, train_ratio: float, seed: int
) -> tuple[list, list]:
    station_ids = list(pd.unique(pd.Series(station_ids)))
    if len(station_ids) < 4:
        raise ValueError("至少需要 4 个站点，才能做按站点的训练/验证划分。")
    rng = np.random.default_rng(seed)
    rng.shuffle(station_ids)
    train_count = int(round(len(station_ids) * train_ratio))
    train_count = min(max(train_count, 2), len(station_ids) - 1)
    return station_ids[:train_count], station_ids[train_count:]


def _make_loader(
    dataset: StationSequenceDataset,
    batch_size: int,
    shuffle: bool,
    num_workers: int,
    seed: int,
) -> DataLoader:
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        generator=generator,
    )


@dataclass
class FitResult:
    state_dict: dict[str, torch.Tensor]
    best_epoch: int
    best_val_loss: float
    history: list[dict[str, float]]


def fit_with_early_stopping(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    device: torch.device,
    learning_rate: float,
    weight_decay: float,
    max_epochs: int,
    patience: int,
) -> FitResult:
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=learning_rate, weight_decay=weight_decay
    )
    criterion = nn.MSELoss()
    best_loss = float("inf")
    best_epoch = 1
    best_state = copy.deepcopy(model.state_dict())
    wait = 0
    history: list[dict[str, float]] = []

    for epoch in range(1, max_epochs + 1):
        model.train()
        train_sum = 0.0
        train_count = 0
        for x_sequence, y_history, target, _ in train_loader:
            x_sequence = x_sequence.to(device)
            y_history = y_history.to(device)
            target = target.to(device)
            optimizer.zero_grad(set_to_none=True)
            prediction = model(x_sequence, y_history)
            loss = criterion(prediction, target)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            train_sum += float(loss.item()) * len(target)
            train_count += len(target)

        model.eval()
        val_sum = 0.0
        val_count = 0
        with torch.inference_mode():
            for x_sequence, y_history, target, _ in val_loader:
                x_sequence = x_sequence.to(device)
                y_history = y_history.to(device)
                target = target.to(device)
                prediction = model(x_sequence, y_history)
                loss = criterion(prediction, target)
                val_sum += float(loss.item()) * len(target)
                val_count += len(target)

        train_loss = train_sum / max(train_count, 1)
        val_loss = val_sum / max(val_count, 1)
        history.append(
            {"epoch": epoch, "train_loss": train_loss, "val_loss": val_loss}
        )

        if val_loss < best_loss - 1e-6:
            best_loss = val_loss
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                break

    return FitResult(best_state, best_epoch, best_loss, history)


def fit_fixed_epochs(
    model: nn.Module,
    train_loader: DataLoader,
    device: torch.device,
    learning_rate: float,
    weight_decay: float,
    epochs: int,
) -> list[float]:
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=learning_rate, weight_decay=weight_decay
    )
    criterion = nn.MSELoss()
    losses: list[float] = []
    for epoch in range(1, epochs + 1):
        model.train()
        epoch_sum = 0.0
        epoch_count = 0
        for x_sequence, y_history, target, _ in train_loader:
            x_sequence = x_sequence.to(device)
            y_history = y_history.to(device)
            target = target.to(device)
            optimizer.zero_grad(set_to_none=True)
            prediction = model(x_sequence, y_history)
            loss = criterion(prediction, target)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            epoch_sum += float(loss.item()) * len(target)
            epoch_count += len(target)
        losses.append(epoch_sum / max(epoch_count, 1))
        if epoch == 1 or epoch == epochs or epoch % 5 == 0:
            print(f"  最终训练 epoch {epoch:>3}/{epochs}: loss={losses[-1]:.5f}")
    return losses


def evaluate_model(
    model: nn.Module,
    dataset: StationSequenceDataset,
    batch_size: int,
    num_workers: int,
    device: torch.device,
    scaler: Standardization,
) -> tuple[dict[str, float], pd.DataFrame]:
    loader = _make_loader(
        dataset, batch_size, False, num_workers, seed=0
    )
    predictions_normalized: list[np.ndarray] = []
    targets_normalized: list[np.ndarray] = []
    sample_indices: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for x_sequence, y_history, target, indices in loader:
            prediction = model(
                x_sequence.to(device), y_history.to(device)
            )
            predictions_normalized.append(prediction.cpu().numpy())
            targets_normalized.append(target.numpy())
            sample_indices.append(indices.numpy())

    prediction = scaler.inverse_y(np.concatenate(predictions_normalized))
    target = scaler.inverse_y(np.concatenate(targets_normalized))
    indices = np.concatenate(sample_indices).astype(int)
    metadata = [dataset.metadata[index] for index in indices]
    prediction_frame = pd.DataFrame(
        {
            "site_id": [item[0] for item in metadata],
            "date": [item[1] for item in metadata],
            "observed": target,
            "predicted": prediction,
        }
    )
    metrics = regression_metrics(target, prediction)
    return metrics, prediction_frame


def regression_metrics(
    observed: np.ndarray, predicted: np.ndarray
) -> dict[str, float]:
    return {
        "r2": float(r2_score(observed, predicted)),
        "rmse": float(np.sqrt(mean_squared_error(observed, predicted))),
        "mae": float(mean_absolute_error(observed, predicted)),
    }


def _valid_random_params(
    search_space: dict[str, list], rng: random.Random
) -> dict[str, Any]:
    while True:
        params = {
            key: rng.choice(values) for key, values in search_space.items()
        }
        if params["patch_len"] > params["x_window"]:
            continue
        if params["d_model"] % params["n_heads"] != 0:
            continue
        return params


def build_trial_params(
    search_space: dict[str, list],
    num_trials: int,
    seed: int,
    representative_x_window: int,
    representative_y_lags: int,
) -> list[dict[str, Any]]:
    # Shared network defaults for the three required scientific comparisons.
    network_default = {
        "x_window": representative_x_window,
        "y_lags": representative_y_lags,
        "patch_len": min(3, representative_x_window),
        "d_model": 24,
        "n_heads": 4,
        "temporal_layers": 1,
        "variable_layers": 1,
        "lstm_hidden": 32,
        "dropout": 0.15,
        "learning_rate": 0.0007,
        "weight_decay": 0.0001,
        "batch_size": 128,
    }
    for key, values in search_space.items():
        if network_default[key] not in values:
            network_default[key] = values[0]
    if network_default["d_model"] % network_default["n_heads"] != 0:
        network_default["n_heads"] = next(
            head
            for head in search_space["n_heads"]
            if network_default["d_model"] % head == 0
        )
    if network_default["patch_len"] > network_default["x_window"]:
        network_default["patch_len"] = min(
            value
            for value in search_space["patch_len"]
            if value <= network_default["x_window"]
        )

    m0 = dict(network_default)
    m0.update({"x_window": 1, "y_lags": 0, "patch_len": 1})
    m1 = dict(network_default)
    m1["y_lags"] = 0
    m2 = dict(network_default)

    rng = random.Random(seed)
    trials = [m0, m1, m2][:num_trials]
    seen = {json.dumps(params, sort_keys=True) for params in trials}
    attempts = 0
    while len(trials) < num_trials and attempts < num_trials * 100:
        params = _valid_random_params(search_space, rng)
        key = json.dumps(params, sort_keys=True)
        if key not in seen:
            trials.append(params)
            seen.add(key)
        attempts += 1
    return trials


def model_variant(params: dict[str, Any]) -> str:
    if int(params["x_window"]) == 1 and int(params["y_lags"]) == 0:
        return "M0_current_X"
    if int(params["y_lags"]) == 0:
        return "M1_window_X"
    return "M2_window_X_history_Y"


def save_diagnostic_plots(
    prediction_frame: pd.DataFrame,
    output_dir: Path,
    trial_frame: pd.DataFrame,
) -> None:
    observed = prediction_frame["observed"].to_numpy()
    predicted = prediction_frame["predicted"].to_numpy()
    lower = min(float(observed.min()), float(predicted.min()))
    upper = max(float(observed.max()), float(predicted.max()))

    fig, ax = plt.subplots(figsize=(6.2, 5.6), dpi=150)
    ax.scatter(observed, predicted, s=12, alpha=0.45, edgecolors="none")
    ax.plot([lower, upper], [lower, upper], "--", color="black", linewidth=1)
    ax.set_xlabel("Observed Y")
    ax.set_ylabel("Predicted Y")
    ax.set_title("Held-out station validation")
    fig.tight_layout()
    fig.savefig(output_dir / "validation_scatter.png")
    plt.close(fig)

    residual = predicted - observed
    fig, ax = plt.subplots(figsize=(6.2, 4.5), dpi=150)
    ax.scatter(predicted, residual, s=12, alpha=0.45, edgecolors="none")
    ax.axhline(0, linestyle="--", color="black", linewidth=1)
    ax.set_xlabel("Predicted Y")
    ax.set_ylabel("Residual (predicted - observed)")
    fig.tight_layout()
    fig.savefig(output_dir / "validation_residuals.png")
    plt.close(fig)

    if not trial_frame.empty:
        fig, ax = plt.subplots(figsize=(6.2, 4.2), dpi=150)
        ax.bar(
            trial_frame["trial"].astype(str),
            trial_frame["internal_r2"],
            color="#3d7ea6",
        )
        ax.set_xlabel("Trial")
        ax.set_ylabel("Internal station R2")
        ax.set_title("Automatic parameter search")
        fig.tight_layout()
        fig.savefig(output_dir / "parameter_search.png")
        plt.close(fig)


def train_pipeline(
    frame: pd.DataFrame,
    feature_columns: list[str],
    config: dict[str, Any],
    output_dir: Path,
) -> dict[str, Any]:
    site_column = config["data"]["site_column"]
    time_column = config["data"]["time_column"]
    target_column = config["data"]["target_column"]
    seed = int(config["split"]["seed"])
    training_config = config["training"]
    num_workers = int(training_config["num_workers"])
    device = choose_device(training_config["device"])
    seed_everything(seed)
    output_dir.mkdir(parents=True, exist_ok=True)

    all_station_ids = frame[site_column].unique().tolist()
    train_sites, test_sites = split_station_ids(
        all_station_ids,
        float(config["split"]["train_station_ratio"]),
        seed,
    )
    tuning_train_sites, tuning_val_sites = split_station_ids(
        train_sites, 0.82, seed + 17
    )
    split_frame = pd.DataFrame(
        {
            "site_id": [str(item) for item in train_sites + test_sites],
            "split": ["train"] * len(train_sites) + ["held_out"] * len(test_sites),
        }
    )
    split_frame.to_csv(output_dir / "station_split.csv", index=False)

    train_rows = frame[frame[site_column].isin(train_sites)]
    scaler = Standardization.fit(
        train_rows, feature_columns + [target_column]
    )
    print(
        f"\n站点划分：总计 {len(all_station_ids)}，"
        f"训练池 {len(train_sites)}，最终独立验证 {len(test_sites)}"
    )
    print(
        f"调参只在训练池内部进行：{len(tuning_train_sites)} 个内部训练站点，"
        f"{len(tuning_val_sites)} 个内部验证站点"
    )
    print(f"计算设备：{device}；X 变量：{feature_columns}")

    trial_params = build_trial_params(
        training_config["search_space"],
        int(training_config["num_trials"]),
        seed,
        int(training_config["representative_x_window"]),
        int(training_config["representative_y_lags"]),
    )
    trial_records: list[dict[str, Any]] = []
    best_params: dict[str, Any] | None = None
    best_internal_r2 = -float("inf")
    best_epoch = 1

    print("\n开始自动调参：")
    for trial_number, params in enumerate(trial_params, start=1):
        trial_start = time.time()
        seed_everything(seed + trial_number)
        train_dataset = StationSequenceDataset(
            frame,
            tuning_train_sites,
            site_column,
            time_column,
            feature_columns,
            target_column,
            int(params["x_window"]),
            int(params["y_lags"]),
            scaler,
        )
        val_dataset = StationSequenceDataset(
            frame,
            tuning_val_sites,
            site_column,
            time_column,
            feature_columns,
            target_column,
            int(params["x_window"]),
            int(params["y_lags"]),
            scaler,
        )
        train_loader = _make_loader(
            train_dataset,
            int(params["batch_size"]),
            True,
            num_workers,
            seed + trial_number,
        )
        val_loader = _make_loader(
            val_dataset,
            int(params["batch_size"]),
            False,
            num_workers,
            seed + trial_number,
        )
        model = build_model(len(feature_columns), params)
        fit_result = fit_with_early_stopping(
            model,
            train_loader,
            val_loader,
            device,
            float(params["learning_rate"]),
            float(params["weight_decay"]),
            int(training_config["max_epochs"]),
            int(training_config["early_stopping_patience"]),
        )
        model.load_state_dict(fit_result.state_dict)
        internal_metrics, _ = evaluate_model(
            model,
            val_dataset,
            int(params["batch_size"]),
            num_workers,
            device,
            scaler,
        )
        elapsed = time.time() - trial_start
        record = {
            "trial": trial_number,
            "internal_r2": internal_metrics["r2"],
            "internal_rmse": internal_metrics["rmse"],
            "best_epoch": fit_result.best_epoch,
            "parameters": count_parameters(model),
            "seconds": round(elapsed, 2),
            "variant": model_variant(params),
            **params,
        }
        trial_records.append(record)
        print(
            f"  trial {trial_number}/{len(trial_params)}: "
            f"{model_variant(params)}, "
            f"R2={internal_metrics['r2']:.4f}, "
            f"RMSE={internal_metrics['rmse']:.3f}, "
            f"epoch={fit_result.best_epoch}, {elapsed:.1f}s"
        )
        if internal_metrics["r2"] > best_internal_r2:
            best_internal_r2 = internal_metrics["r2"]
            best_params = dict(params)
            best_epoch = fit_result.best_epoch

    if best_params is None:
        raise RuntimeError("自动调参没有得到可用模型。")
    trial_frame = pd.DataFrame(trial_records)
    trial_frame.to_csv(output_dir / "parameter_trials.csv", index=False)

    # Retrain from scratch with every station in the 70% training pool.
    final_epochs = max(3, int(best_epoch))
    seed_everything(seed + 999)
    final_train_dataset = StationSequenceDataset(
        frame,
        train_sites,
        site_column,
        time_column,
        feature_columns,
        target_column,
        int(best_params["x_window"]),
        int(best_params["y_lags"]),
        scaler,
    )
    final_test_dataset = StationSequenceDataset(
        frame,
        test_sites,
        site_column,
        time_column,
        feature_columns,
        target_column,
        int(best_params["x_window"]),
        int(best_params["y_lags"]),
        scaler,
    )
    final_train_loader = _make_loader(
        final_train_dataset,
        int(best_params["batch_size"]),
        True,
        num_workers,
        seed + 999,
    )
    final_model = build_model(len(feature_columns), best_params)
    print(
        f"\n最优内部 R2={best_internal_r2:.4f}。"
        f"现用全部 70% 训练站点重训 {final_epochs} 轮："
    )
    final_losses = fit_fixed_epochs(
        final_model,
        final_train_loader,
        device,
        float(best_params["learning_rate"]),
        float(best_params["weight_decay"]),
        final_epochs,
    )
    test_metrics, prediction_frame = evaluate_model(
        final_model,
        final_test_dataset,
        int(best_params["batch_size"]),
        num_workers,
        device,
        scaler,
    )

    per_site_records = []
    for station_id, group in prediction_frame.groupby("site_id"):
        if len(group) >= 2:
            station_metrics = regression_metrics(
                group["observed"].to_numpy(),
                group["predicted"].to_numpy(),
            )
            per_site_records.append(
                {"site_id": station_id, "n": len(group), **station_metrics}
            )
    per_site_frame = pd.DataFrame(per_site_records)
    per_site_frame.to_csv(output_dir / "per_station_metrics.csv", index=False)
    median_station_r2 = (
        float(per_site_frame["r2"].median())
        if not per_site_frame.empty
        else float("nan")
    )

    threshold = float(config["success"]["r2_threshold"])
    succeeded = bool(test_metrics["r2"] >= threshold)
    status = "SUCCESS" if succeeded else "FAILED_THRESHOLD"
    summary = {
        "status": status,
        "success": succeeded,
        "r2_threshold": threshold,
        "held_out_metrics": test_metrics,
        "median_station_r2": median_station_r2,
        "internal_best_r2": best_internal_r2,
        "best_params": best_params,
        "final_epochs": final_epochs,
        "num_x": len(feature_columns),
        "feature_columns": feature_columns,
        "target_column": target_column,
        "history_includes_y": bool(int(best_params["y_lags"]) > 0),
        "best_model_variant": model_variant(best_params),
        "train_station_count": len(train_sites),
        "held_out_station_count": len(test_sites),
        "train_sample_count": len(final_train_dataset),
        "held_out_sample_count": len(final_test_dataset),
        "device": str(device),
    }

    prediction_frame.to_csv(
        output_dir / "held_out_predictions.csv", index=False
    )
    with (output_dir / "metrics.json").open("w", encoding="utf-8") as file:
        json.dump(summary, file, ensure_ascii=False, indent=2)
    with (output_dir / "best_params.json").open(
        "w", encoding="utf-8"
    ) as file:
        json.dump(best_params, file, ensure_ascii=False, indent=2)

    checkpoint = {
        "model_state_dict": {
            key: value.detach().cpu()
            for key, value in final_model.state_dict().items()
        },
        "model_params": best_params,
        "feature_columns": feature_columns,
        "target_column": target_column,
        "site_column": site_column,
        "time_column": time_column,
        "scaler": scaler.to_dict(),
        "validation_metrics": test_metrics,
        "r2_threshold": threshold,
        "success": succeeded,
    }
    torch.save(checkpoint, output_dir / "best_model.pt")
    save_diagnostic_plots(prediction_frame, output_dir, trial_frame)

    # Save a compact final-training curve.
    pd.DataFrame(
        {
            "epoch": np.arange(1, len(final_losses) + 1),
            "train_loss": final_losses,
        }
    ).to_csv(output_dir / "final_training_curve.csv", index=False)
    return summary
